import type { Metadata } from 'next';
import { Suspense } from 'react';
import { CourseListings } from '@/components/course/CourseListings';

export const metadata: Metadata = {
  title: 'Browse Courses',
  description: 'Explore 500+ expert-led courses in web development, data science, design, and more.',
};

export default function CoursesPage({
  searchParams,
}: {
  searchParams: Record<string, string>;
}) {
  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      {/* Page Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Browse Courses</h1>
          <p className="text-gray-500">Expand your knowledge with expert-led courses</p>
        </div>
      </div>
      
      <Suspense fallback={<CoursesLoadingSkeleton />}>
        <CourseListings searchParams={searchParams} />
      </Suspense>
    </div>
  );
}

function CoursesLoadingSkeleton() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {Array(8).fill(0).map((_, i) => (
          <div key={i} className="card overflow-hidden">
            <div className="aspect-video skeleton" />
            <div className="p-5 space-y-3">
              <div className="h-4 skeleton rounded w-3/4" />
              <div className="h-3 skeleton rounded" />
              <div className="h-3 skeleton rounded w-2/3" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
