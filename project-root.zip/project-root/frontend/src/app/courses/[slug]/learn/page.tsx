'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  ChevronLeft, ChevronRight, CheckCircle, Circle, Play, Lock,
  MessageSquare, FileText, BookOpen, Menu, X, Volume2
} from 'lucide-react';
import Hls from 'hls.js';
import { useQuery, useMutation } from '@tanstack/react-query';
import { courseApi, progressApi, videoApi, enrollmentApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

export default function CoursePlayerPage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, isAuthenticated } = useAuthStore();
  const courseSlug = params.slug as string;

  const [currentLessonId, setCurrentLessonId] = useState<string | null>(searchParams.get('lesson'));
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'notes' | 'discussion'>('overview');
  const [notes, setNotes] = useState('');
  const [discussionContent, setDiscussionContent] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) router.push(`/auth/login?redirect=/courses/${courseSlug}/learn`);
  }, [isAuthenticated]);

  // Fetch course data
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: ['course-learn', courseSlug],
    queryFn: () => courseApi.getBySlug(courseSlug).then(r => r.data.data),
    enabled: isAuthenticated,
  });

  // Flatten all lessons
  const allLessons = course?.curriculum?.flatMap((m: any) =>
    (m.lessons || []).map((l: any) => ({ ...l, module_title: m.title }))
  ) || [];

  const currentLesson = allLessons.find((l: any) => l.id === currentLessonId) || allLessons[0];
  const currentIndex = allLessons.findIndex((l: any) => l.id === currentLesson?.id);

  // Fetch course progress
  const { data: progressData, refetch: refetchProgress } = useQuery({
    queryKey: ['course-progress', course?.id],
    queryFn: () => progressApi.getCourseProgress(course!.id).then(r => r.data.data),
    enabled: !!course?.id && isAuthenticated,
  });

  const completedLessons = new Set(
    (progressData?.lessons || []).filter((p: any) => p.is_completed).map((p: any) => p.lesson_id)
  );

  // Fetch video signed URL
  const { data: videoAccess, refetch: refetchVideoAccess } = useQuery({
    queryKey: ['video-access', currentLesson?.id],
    queryFn: () => videoApi.requestAccess(currentLesson!.id).then(r => r.data.data),
    enabled: !!currentLesson?.id && isAuthenticated,
    staleTime: 50 * 60 * 1000, // 50 min
  });

  // Update progress mutation
  const updateProgress = useMutation({
    mutationFn: ({ lessonId, data }: { lessonId: string; data: any }) =>
      progressApi.updateLessonProgress(lessonId, data),
    onSuccess: () => refetchProgress(),
  });

  // Initialize HLS player
  useEffect(() => {
    if (!videoRef.current || !videoAccess?.signedUrl) return;

    if (hlsRef.current) {
      hlsRef.current.destroy();
    }

    const videoUrl = `${process.env.NEXT_PUBLIC_API_URL}${videoAccess.signedUrl}`;

    if (Hls.isSupported()) {
      const hls = new Hls({
        xhrSetup: (xhr) => {
          xhr.setRequestHeader('Authorization', `Bearer ${localStorage.getItem('auth-storage') ? JSON.parse(localStorage.getItem('auth-storage')!).state.accessToken : ''}`);
        },
      });
      hls.loadSource(videoUrl);
      hls.attachMedia(videoRef.current);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        videoRef.current?.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          toast.error('Video loading error. Please refresh.');
        }
      });
      hlsRef.current = hls;
    } else if (videoRef.current.canPlayType('application/vnd.apple.mpegurl')) {
      videoRef.current.src = videoUrl;
      videoRef.current.play().catch(() => {});
    }

    return () => {
      hlsRef.current?.destroy();
    };
  }, [videoAccess?.signedUrl]);

  // Track progress every 10 seconds
  useEffect(() => {
    if (!videoRef.current || !currentLesson) return;

    const handleTimeUpdate = () => {
      const video = videoRef.current;
      if (!video) return;
      const pct = (video.currentTime / video.duration) * 100;
      if (pct > 90 && !completedLessons.has(currentLesson.id)) {
        updateProgress.mutate({
          lessonId: currentLesson.id,
          data: { is_completed: true, watch_time: Math.floor(video.currentTime), last_position: Math.floor(video.currentTime) }
        });
      }
    };

    progressIntervalRef.current = setInterval(() => {
      if (videoRef.current && currentLesson) {
        updateProgress.mutate({
          lessonId: currentLesson.id,
          data: {
            is_completed: completedLessons.has(currentLesson.id),
            watch_time: Math.floor(videoRef.current.currentTime),
            last_position: Math.floor(videoRef.current.currentTime),
          }
        });
      }
    }, 30000);

    videoRef.current.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
      videoRef.current?.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [currentLesson?.id]);

  // Disable right click on video
  useEffect(() => {
    const handler = (e: MouseEvent) => e.preventDefault();
    document.querySelector('.video-container')?.addEventListener('contextmenu', handler);
    return () => document.querySelector('.video-container')?.removeEventListener('contextmenu', handler);
  }, []);

  const goToLesson = (lessonId: string) => {
    setCurrentLessonId(lessonId);
    router.replace(`/courses/${courseSlug}/learn?lesson=${lessonId}`, { scroll: false });
  };

  const markComplete = () => {
    if (!currentLesson) return;
    updateProgress.mutate({
      lessonId: currentLesson.id,
      data: { is_completed: true, watch_time: Math.floor(videoRef.current?.currentTime || 0), last_position: 0 }
    });
    toast.success('Lesson marked as complete!');
    if (currentIndex < allLessons.length - 1) {
      setTimeout(() => goToLesson(allLessons[currentIndex + 1].id), 800);
    }
  };

  if (courseLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p>Loading course...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-900 overflow-hidden">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 overflow-hidden bg-gray-800 border-r border-gray-700 flex flex-col shrink-0`}>
        <div className="p-4 border-b border-gray-700">
          <Link href={`/courses/${courseSlug}`} className="flex items-center gap-2 text-gray-300 hover:text-white text-sm mb-3 transition-colors">
            <ChevronLeft className="w-4 h-4" /> Back to course
          </Link>
          <h2 className="text-white font-semibold text-sm leading-tight">{course?.title}</h2>
          <div className="mt-2 bg-gray-700 rounded-full h-1.5">
            <div
              className="bg-primary-500 h-1.5 rounded-full transition-all"
              style={{ width: `${progressData?.progress_percentage || 0}%` }}
            />
          </div>
          <p className="text-xs text-gray-400 mt-1">{progressData?.progress_percentage || 0}% complete</p>
        </div>

        <div className="flex-1 overflow-y-auto">
          {course?.curriculum?.map((module: any) => (
            <div key={module.id}>
              <div className="px-4 py-3 bg-gray-750 border-b border-gray-700">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">{module.title}</p>
              </div>
              {(module.lessons || []).map((lesson: any) => {
                const isCompleted = completedLessons.has(lesson.id);
                const isCurrent = lesson.id === currentLesson?.id;
                return (
                  <button
                    key={lesson.id}
                    onClick={() => goToLesson(lesson.id)}
                    className={`w-full flex items-start gap-3 px-4 py-3 text-left transition-colors border-b border-gray-700/50 ${
                      isCurrent ? 'bg-primary-900/50 border-l-2 border-l-primary-500' : 'hover:bg-gray-700/50'
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-accent-400" />
                      ) : isCurrent ? (
                        <Play className="w-4 h-4 text-primary-400 fill-primary-400" />
                      ) : (
                        <Circle className="w-4 h-4 text-gray-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm leading-tight truncate ${isCurrent ? 'text-white font-medium' : 'text-gray-300'}`}>
                        {lesson.title}
                      </p>
                      {lesson.video_duration > 0 && (
                        <p className="text-xs text-gray-500 mt-0.5">
                          {Math.floor(lesson.video_duration / 60)}:{String(lesson.video_duration % 60).padStart(2, '0')}
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <div className="bg-gray-900 border-b border-gray-700 px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-400 hover:text-white p-1 transition-colors">
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h1 className="text-white font-medium text-sm truncate max-w-xs lg:max-w-lg">
              {currentLesson?.title}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => currentIndex > 0 && goToLesson(allLessons[currentIndex - 1].id)}
              disabled={currentIndex === 0}
              className="p-2 text-gray-400 hover:text-white disabled:opacity-30 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => currentIndex < allLessons.length - 1 && goToLesson(allLessons[currentIndex + 1].id)}
              disabled={currentIndex === allLessons.length - 1}
              className="p-2 text-gray-400 hover:text-white disabled:opacity-30 transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={markComplete}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                completedLessons.has(currentLesson?.id)
                  ? 'bg-accent-600/20 text-accent-400'
                  : 'bg-primary-600 hover:bg-primary-700 text-white'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              {completedLessons.has(currentLesson?.id) ? 'Completed' : 'Mark Complete'}
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Video player */}
          <div className="bg-black video-container relative w-full" style={{ maxHeight: '60vh' }}>
            {currentLesson?.content_type === 'video' ? (
              <>
                <video
                  ref={videoRef}
                  className="w-full h-full object-contain"
                  controls
                  controlsList="nodownload"
                  playsInline
                  style={{ maxHeight: '60vh' }}
                />
                {/* Dynamic watermark */}
                {user && videoAccess?.watermark && (
                  <div className="absolute inset-0 pointer-events-none flex items-end justify-end p-4 opacity-30">
                    <div className="text-white text-xs font-mono bg-black/50 px-2 py-1 rounded select-none">
                      {videoAccess.watermark.email} • {new Date(videoAccess.watermark.timestamp).toLocaleDateString()}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="flex items-center justify-center h-64 text-gray-400">
                <div className="text-center">
                  <FileText className="w-12 h-12 mx-auto mb-3" />
                  <p>Text lesson</p>
                </div>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div className="bg-white border-b border-gray-200">
            <div className="max-w-4xl mx-auto px-4 flex gap-1">
              {(['overview', 'notes', 'discussion'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3.5 text-sm font-medium border-b-2 transition-colors capitalize ${
                    activeTab === tab ? 'border-primary-600 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {/* Tab content */}
          <div className="max-w-4xl mx-auto px-4 py-8">
            {activeTab === 'overview' && (
              <div>
                <h2 className="text-xl font-bold text-gray-900 mb-3">{currentLesson?.title}</h2>
                {currentLesson?.description && (
                  <p className="text-gray-600 leading-relaxed">{currentLesson.description}</p>
                )}
                {currentLesson?.content_text && (
                  <div className="prose mt-6" dangerouslySetInnerHTML={{ __html: currentLesson.content_text }} />
                )}
              </div>
            )}

            {activeTab === 'notes' && (
              <div>
                <h3 className="font-semibold text-gray-900 mb-4">My Notes</h3>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Take notes for this lesson..."
                  className="input w-full h-48 resize-none"
                />
                <button
                  onClick={() => {
                    updateProgress.mutate({ lessonId: currentLesson?.id, data: { notes, is_completed: false } });
                    toast.success('Notes saved!');
                  }}
                  className="btn-primary mt-3"
                >
                  Save Notes
                </button>
              </div>
            )}

            {activeTab === 'discussion' && (
              <LessonDiscussion lessonId={currentLesson?.id} userId={user?.id} userFullName={user?.full_name} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function LessonDiscussion({ lessonId, userId, userFullName }: { lessonId: string; userId?: string; userFullName?: string }) {
  const [content, setContent] = useState('');
  const API_URL = process.env.NEXT_PUBLIC_API_URL;

  const { data: discussions, refetch } = useQuery({
    queryKey: ['discussions', lessonId],
    queryFn: async () => {
      const api = (await import('@/lib/api')).default;
      const r = await api.get(`/lessons/${lessonId}/discussions`);
      return r.data.data;
    },
    enabled: !!lessonId,
  });

  const postDiscussion = useMutation({
    mutationFn: async () => {
      const api = (await import('@/lib/api')).default;
      await api.post(`/lessons/${lessonId}/discussions`, { content });
    },
    onSuccess: () => { setContent(''); refetch(); toast.success('Comment posted!'); },
    onError: () => toast.error('Failed to post comment'),
  });

  return (
    <div>
      <h3 className="font-semibold text-gray-900 mb-6">Discussion ({discussions?.length || 0})</h3>
      <div className="mb-6">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Ask a question or share insights..."
          className="input w-full h-28 resize-none mb-3"
        />
        <button
          onClick={() => content.trim() && postDiscussion.mutate()}
          disabled={!content.trim() || postDiscussion.isPending}
          className="btn-primary"
        >
          {postDiscussion.isPending ? 'Posting...' : 'Post Comment'}
        </button>
      </div>
      <div className="space-y-4">
        {discussions?.map((d: any) => (
          <div key={d.id} className="flex gap-3">
            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center shrink-0">
              <span className="text-primary-700 text-xs font-semibold">{d.full_name?.charAt(0)}</span>
            </div>
            <div className="flex-1 bg-gray-50 rounded-lg p-3">
              <p className="text-sm font-medium text-gray-900 mb-1">{d.full_name}</p>
              <p className="text-sm text-gray-700 leading-relaxed">{d.content}</p>
              <p className="text-xs text-gray-400 mt-2">{new Date(d.created_at).toLocaleDateString()}</p>
            </div>
          </div>
        ))}
        {discussions?.length === 0 && (
          <p className="text-center text-gray-400 py-8">No discussions yet. Be the first to ask!</p>
        )}
      </div>
    </div>
  );
}
