import type { Metadata } from 'next';
import Link from 'next/link';
import { Calendar, Clock, Eye, Tag } from 'lucide-react';
import { AdBanner } from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'Blog - Tips, Tutorials & Industry Insights',
  description: 'Read expert articles on web development, data science, design, and more.',
};

async function getArticles(params: Record<string, string>) {
  const qs = new URLSearchParams({ ...params, limit: '9' }).toString();
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/articles?${qs}`, {
      next: { revalidate: 300 }
    });
    if (!res.ok) return { articles: [], pagination: {} };
    const data = await res.json();
    return data.data;
  } catch { return { articles: [], pagination: {} }; }
}

async function getCategories() {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/categories`, { next: { revalidate: 3600 } });
    if (!res.ok) return [];
    return (await res.json()).data || [];
  } catch { return []; }
}

async function getPopularArticles() {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/articles/popular`, { next: { revalidate: 600 } });
    if (!res.ok) return [];
    return (await res.json()).data || [];
  } catch { return []; }
}

export default async function BlogPage({ searchParams }: { searchParams: Record<string, string> }) {
  const [{ articles, pagination }, categories, popular] = await Promise.all([
    getArticles(searchParams),
    getCategories(),
    getPopularArticles(),
  ]);

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      {/* Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Blog</h1>
          <p className="text-gray-500">Expert insights, tutorials, and industry news</p>
        </div>
      </div>

      {/* Blog header ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <AdBanner placement="blog_header" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-10">
          {/* Articles grid */}
          <div className="lg:col-span-3">
            {/* Category filters */}
            <div className="flex flex-wrap gap-2 mb-8">
              <Link
                href="/blog"
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  !searchParams.category ? 'bg-primary-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-primary-300'
                }`}
              >
                All
              </Link>
              {categories.slice(0, 8).map((cat: any) => (
                <Link
                  key={cat.slug}
                  href={`/blog?category=${cat.slug}`}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    searchParams.category === cat.slug
                      ? 'bg-primary-600 text-white'
                      : 'bg-white border border-gray-200 text-gray-600 hover:border-primary-300'
                  }`}
                >
                  {cat.name}
                </Link>
              ))}
            </div>

            {articles.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {articles.map((article: any) => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-gray-500">No articles found.</p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-8">
            {/* Sidebar Ad */}
            <AdBanner placement="blog_sidebar" />

            {/* Popular articles */}
            {popular.length > 0 && (
              <div className="bg-white rounded-xl border border-gray-100 p-5">
                <h3 className="font-bold text-gray-900 mb-4">Popular Articles</h3>
                <div className="space-y-4">
                  {popular.map((article: any, i: number) => (
                    <Link key={article.id} href={`/blog/${article.slug}`} className="flex gap-3 group">
                      <span className="text-2xl font-bold text-gray-200 shrink-0 w-7">{i + 1}</span>
                      <div>
                        <p className="text-sm font-medium text-gray-800 group-hover:text-primary-600 transition-colors line-clamp-2">
                          {article.title}
                        </p>
                        <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                          <Eye className="w-3 h-3" /> {article.view_count.toLocaleString()} views
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Categories */}
            <div className="bg-white rounded-xl border border-gray-100 p-5">
              <h3 className="font-bold text-gray-900 mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((cat: any) => (
                  <Link
                    key={cat.slug}
                    href={`/blog?category=${cat.slug}`}
                    className="flex items-center justify-between py-1.5 text-sm text-gray-600 hover:text-primary-600 transition-colors"
                  >
                    <span>{cat.name}</span>
                    <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{cat.article_count}</span>
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

function ArticleCard({ article }: { article: any }) {
  return (
    <Link href={`/blog/${article.slug}`} className="card group block overflow-hidden">
      <div className="aspect-video overflow-hidden bg-gray-100">
        {article.cover_image_url ? (
          <img
            src={article.cover_image_url}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary-50 to-primary-100 flex items-center justify-center">
            <Tag className="w-8 h-8 text-primary-300" />
          </div>
        )}
      </div>
      <div className="p-5">
        {article.category_name && (
          <p className="text-xs font-medium text-primary-600 uppercase tracking-wide mb-2">{article.category_name}</p>
        )}
        <h2 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
          {article.title}
        </h2>
        {article.excerpt && (
          <p className="text-sm text-gray-500 mb-4 line-clamp-2">{article.excerpt}</p>
        )}
        <div className="flex items-center justify-between text-xs text-gray-400 pt-3 border-t border-gray-100">
          <span className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            {new Date(article.published_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {article.read_time} min read
          </span>
        </div>
      </div>
    </Link>
  );
}
